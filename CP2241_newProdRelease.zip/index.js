"use strict";

var PLATFORM = "vungle";

var runGame = function runGame() {
  if (runGame.launched) return;
  runGame.launched = true;
  if (window.__callSDK) window.callSDK = window.__callSDK;
  document.body.style.width = '100%';
  document.body.style.height = '100%';
  document.body.style.position = 'fixed';
  var list = document.getElementsByTagName('html');

  for (var i = 0; i < list.length; i++) {
    list[i].style.width = '100%';
    list[i].style.height = '100%';
    list[i].style.position = 'fixed';
  }

  window.addEventListener('ad-event-pause', function () {
    if (Game.pause) Game.pause();
  });
  window.addEventListener('ad-event-resume', function () {
    if (Game.resume) Game.resume();
  });
  window.addEventListener('ad-event-init', function () {
    if (window.VungleHelper) {
      Game.platformData = window.VungleHelper;
    }
  });
  Game.init(document.getElementById("vungle-ad"));
  Game.on("gameEvent", GameEvents.handleEvent);
  Game.on("gameEvent", function (e) {
    if (e.type === "outroComplete") callSDK("complete");
  });

  try {
    initListeners();
    mraid.expand();
  } catch (e) {} finally {
    LayoutManager.fitLayout();
  }
};

var domReadyHandler = function domReadyHandler() {
  window.removeEventListener("load", domReadyHandler);
  runGame();
};

var mraidReadyHandler = function mraidReadyHandler() {
  mraid.removeEventListener("ready", mraidReadyHandler);
  console.log("MRAID ready", window.location.href);

  if (mraid.isViewable()) {
    console.log("MRAID not viewable");
    return mraidViewableHandler(true);
  }

  mraid.addEventListener("viewableChange", mraidViewableHandler);
};

var mraidViewableHandler = function mraidViewableHandler(flag) {
  if (flag) {
    console.log("MRAID viewable", window.location.href);
    mraid.removeEventListener("viewableChange", mraidViewableHandler);
    runGame();
  }
};

var initListeners = function initListeners() {
  window.addEventListener("resize", LayoutManager.fitLayout);
  setInterval(LayoutManager.fitLayout, 100);
  mraid.addEventListener("stateChange", function (state) {
    if (state === "expanded") {
      runGame();
      LayoutManager.fitLayout();
    }
  });
  mraid.addEventListener("sizeChange", function () {
    console.log("MRAID sizeChange");
    LayoutManager.fitLayout();
  });
  mraid.addEventListener("viewableChange", function () {
    console.log("MRAID viewableChange");
    LayoutManager.fitLayout();
  });
  mraid.addEventListener("error", function () {
    console.log("MRAID error");
  });
};

var GameEvents = function (config) {
  var events = [];

  if (config) {
    for (var key in config) {
      var event = Object.assign({}, config[key]);
      event.name = key;
      event.completed = false;
      event.active = !event.activation;
      events.push(event);
    }
  }

  var handleEvent = function handleEvent(e) {
    for (var i = 0; i < events.length; i++) {
      var _event = events[i];

      if (!_event.active && e.type === _event.activation) {
        _event.active = true;
      }

      if (!_event.completed && _event.active) {
        if (e.type === "tick" && _event.time) {
          _event.time -= e.data;
          if (_event.time <= 0) reportEvent(_event);
        }

        if (e.type === "interaction" && _event.interactions) {
          _event.interactions--;
          if (_event.interactions <= 0) reportEvent(_event);
        }
      }
    }
  };

  var reportEvent = function reportEvent(event) {
    event.completed = true;
    callSDK(event.name);

    if (event.cta) {
      callSDK("download");
    }
  };

  return {
    handleEvent: handleEvent,
    reportEvent: reportEvent
  };
}(CONFIG.gameEvents);

var callSDK = function callSDK(e) {
  if (e === "download" || e === "complete") {
    parent.postMessage(e, "*");
  }

  Game.emit('callSDK', e);
};

window.__callSDK = callSDK;

function getDeviceLang() {
  var lang;

  if (navigator.userLanguage) {
    lang = navigator.userLanguage;
    if (lang.indexOf('zh') == -1) lang = lang.split("-")[0].toLowerCase();
  } else if (navigator.language) {
    lang = navigator.language;
    if (lang.indexOf('zh') == -1) lang = lang.split("-")[0].toLowerCase();
  } else {
    lang = "en";
    if (PiecSettings.defaultLang !== undefined) lang = PiecSettings.defaultLang;
  }

  lang = lang.toLowerCase(); //for simplified and traditional chinese

  if (lang.indexOf('zh') !== -1) {
    if (lang == "zh-tw" || lang == "zh-hk") {
      lang = 'zh-traditional';
    } else {
      lang = 'zh';
    }
  }

  return lang;
}

function getDeviceOS() {
  var userAgent = navigator.userAgent || navigator.vendor || window.opera;
  var device = null;

  if (/windows phone/i.test(userAgent)) {
    device = "windowsPhone";
  }

  if (/android/i.test(userAgent)) {
    device = "android";
  }

  if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
    device = "ios";
  }

  return device;
}

function getDynLocCTA(text) {
  var lang = getDeviceLang();

  if (translations[text] && translations[text][lang] !== undefined) {
    return "" + translations[text][lang];
  }

  return "";
}

var defaultLang = "en";
var translations = {
  'Download': {
    en: "Download",
    ja: "ダウンロード",
    ko: "다운로드",
    zh: "下载",
    de: "Download",
    fr: "Télécharger",
    it: "Scarica",
    es: "Descargar",
    pt: "Baixar",
    ca: "Descarregar",
    ru: "Скачать",
    uk: "Завантажити",
    tr: "Indir",
    nl: "Download",
    sv: "Ladda ner",
    id: "Download",
    ro: "Descărcare",
    ar: "تحميل",
    no: "Nedlasting",
    nb: "Nedlasting",
    nn: "Nedlasting",
    he: "הורד",
    ms: "ഡൗൺലോഡ്",
    th: "ดาวน์โหลด",
    pl: "Pobierz",
    be: "спампаваць",
    el: "κατεβάστε",
    bg: "изтегляне",
    da: "Hent",
    sr: "довнлоад",
    kk: "жүктеу",
    vi: "Tải về",
    hr: "zbirka",
    km: "ទាញយក",
    sq: "Shkarko",
    sl: "prenesi",
    lt: "parsisiųsti",
    az: "yükləyin",
    zu: "ukulanda",
    ga: "íoslódáil",
    is: "sækja",
    hu: "Letöltés",
    lv: "lejupielādēt",
    ka: "ჩამოტვირთვა",
    mt: "niżżel",
    et: "lae alla",
    ne: "डाउनलोड",
    bn: "ডাউনলোড",
    eu: "deskargatu",
    fi: "Lataa",
    sw: "kupakua"
  },
  'Play': {
    en: "Play",
    ja: "遊びます",
    ko: "놀이",
    zh: "玩",
    de: "Abspielen",
    fr: "Jouer",
    it: "Giocare",
    es: "Jugar",
    pt: "Toque",
    ca: "Jugar",
    ru: "Играть",
    uk: "Грати",
    tr: "Oyun",
    nl: "Spelen",
    sv: "Spela",
    id: "Bermain",
    ro: "Joaca",
    ar: "لعب",
    no: "Spille",
    nb: "Spille",
    nn: "Spille",
    he: "לְשַׂחֵק",
    ms: "Bermain",
    th: "เล่น",
    pl: "Grać",
    be: "Гуляць",
    el: "Παίζω",
    bg: "Играйте",
    da: "Spille",
    sr: "Игра",
    kk: "Ойнайық",
    vi: "Chơi",
    hr: "Igra",
    km: "លេង",
    sq: "Luaj",
    sl: "Igraj",
    lt: "Žaisti",
    az: "Oynamaq",
    zu: "Dlala",
    ga: "Seinn",
    is: "Leika",
    hu: "Játék",
    lv: "Spēlēt",
    ka: "ითამაშეთ",
    mt: "Play",
    et: "Mängi",
    ne: "खेल्नु",
    bn: "খেলুন",
    eu: "Jokatu",
    fi: "Pelaa",
    sw: "Jaribu"
  },
  'Play now': {
    en: "Play now",
    ar: "حمل",
    ja: "今すぐプレイ",
    ko: "지금 플레이하세요",
    zh: "马上玩",
    de: "Jetzt spielen",
    fr: "Jouer maintenant",
    it: "Gioca ora",
    es: "Juega ahora",
    pt: "Jogar agora",
    ca: "Juga ara",
    ru: "Играть сейчас",
    uk: "Грати зараз",
    th: "เล่นตอนนี้เลย",
    da: "Spil nu",
    nl: "Speel nu",
    sv: "Spela nu",
    no: "Spill nå",
    el: "Παίξτε τώρα"
  },
  'Play again': {
    en: "Play again",
    ja: "「もう一度プレイ」",
    ko: "다시하기",
    zh: "再次游戏",
    de: "Erneut spielen",
    fr: "Rejouer",
    it: "Gioca di nuovo",
    es: "Juega otra vez",
    pt: "Toque de novo",
    ca: "Torna a jugar",
    ru: "Заново",
    uk: "Грати знову",
    el: "Παίξτε Ξανά"
  },
  'Download now': {
    en: "Download now",
    ja: "今すぐダウンロード",
    ko: "지금 다운로드",
    zh: "立即下載",
    de: "Jetzt downloaden",
    fr: "Télécharger maintenant",
    it: "Scarica ora",
    es: "Descargar ahora",
    pt: "Baixe agora",
    ca: "Descarrega ara",
    ru: "Загрузить сейчас",
    uk: "Завантажити зараз",
    th: "ดาวน์โหลดเลย",
    el: "Κάντε λήψη τώρα"
  },
  'Play free': {
    en: "Play free",
    ja: "無料でプレイ",
    ko: "무료 플레이",
    zh: "免费玩",
    de: "Kostenlos Spielen",
    fr: "Jouez gratuitement",
    it: "Gioca gratis",
    es: "Juega gratis",
    pt: "Jogue grátis",
    ca: "Jugar gratis",
    ru: "Играть бесплатно",
    uk: "Грати безкоштовно",
    th: "เล่นฟรี",
    el: "Παίξτε δωρεάν"
  },
  'Swipe Up': {
    en: "Swipe Up",
    ja: "上にスワイプ",
    ko: "위로 밀기",
    zh: "向上滑动",
    de: "Nach oben wischen",
    fr: "Balayez vers le haut",
    it: "Scorri verso l'alto",
    es: "Desliza hacia arriba",
    pt: "Deslize para cima",
    ca: "Llisca cap amunt",
    ru: "Проведи вверх",
    uk: "Проведи вгору",
    el: "Σάρωση προς τα επάνω"
  },
  'Pop the cubes': {
    en: "Pop the cubes",
    ja: "キューブを消そう",
    ko: "큐브를 터트려요",
    zh: "爆裂方块",
    de: "Lass die Würfel platzen",
    fr: "Faites éclater les cubes",
    it: "Fai scoppiare i cubi",
    es: "Explota los cubos",
    pt: "Estourar os cubos",
    ca: "Esclata els cubs",
    ru: "Лопни кубики",
    uk: "Лопни кубики",
    el: "Σπάσε τους κύβους",
    tr: "Küpleri patlat"
  },
  'Continue': {
    en: "Continue",
    ja: "続行する",
    ko: "계속하기",
    zh: "继续",
    de: "Weiter",
    fr: "Continuer",
    it: "Continua",
    es: "Continuar",
    pt: "Continuar",
    ca: "Continuar",
    ru: "Продолжить",
    uk: "Продовжити",
    el: "Να συνεχίσει"
  },
  'Next level': {
    en: "Next level",
    ja: "次のレベル",
    ko: "다음 레벨",
    zh: "下一关",
    de: "Nächstes Level",
    fr: "Niveau suivant",
    it: "Livello successivo",
    es: "Siguiente nivel",
    pt: "Próximo nível",
    ca: "Següent nivell",
    ru: "Следующий уровень",
    el: "Επόμενο Επίπεδο"
  },
  'Now available to win real cash in [Country Name]!': {
    'en': "Now available to / win real cash / in / the UK!",
    'en-au': "Now available to / win real cash / in / Australia!",
    'en-ca': "Now available to / win real cash / in / Canada!",
    'en-ie': "Now available to / win real cash / in / Ireland!",
    'en-jm': "Now available to / win real cash / in / Jamaica!",
    'en-nz': "Now available to / win real cash / in / New Zealand!",
    'en-ph': "Now available to / win real cash / in / Philippines!",
    'en-za': "Now available to / win real cash / in / South Africa!",
    'en-gb': "Now available to / win real cash / in / the UK!",
    'en-us': "Now available to / win real cash / in / the United States!",
    'es': "¡Ahora puedes / ganar dinero real / en / España!",
    'es-ar': "¡Ahora puedes / ganar dinero real / en / Argentina!",
    'es-bo': "¡Ahora puedes / ganar dinero real / en / Bolivia!",
    'es-cl': "¡Ahora puedes / ganar dinero real / en / Chile!",
    'es-co': "¡Ahora puedes / ganar dinero real / en / Colombia!",
    'es-cr': "¡Ahora puedes / ganar dinero real / en / Costa Rica!",
    'es-do': "¡Ahora puedes / ganar dinero real / en / Rep. Dominicana!",
    'es-ec': "¡Ahora puedes / ganar dinero real / en / Ecuador!",
    'es-sv': "¡Ahora puedes / ganar dinero real / en / El Salvador!",
    'es-gt': "¡Ahora puedes / ganar dinero real / en / Guatemala!",
    'es-hn': "¡Ahora puedes / ganar dinero real / en / Honduras!",
    'es-mx': "¡Ahora puedes / ganar dinero real / en / México!",
    'es-ni': "¡Ahora puedes / ganar dinero real / en / Nicaragua!",
    'es-pa': "¡Ahora puedes / ganar dinero real / en / Panamá!",
    'es-py': "¡Ahora puedes / ganar dinero real / en / Paraguay!",
    'es-pe': "¡Ahora puedes / ganar dinero real / en / Perú!",
    'es-pr': "¡Ahora puedes / ganar dinero real / en / Puerto Rico!",
    'es-es': "¡Ahora puedes / ganar dinero real / en / España!",
    'es-uy': "¡Ahora puedes / ganar dinero real / en / Uruguay!",
    'es-ve': "¡Ahora puedes / ganar dinero real / en / Venezuela!",
    'ar': " متاح الآن للربح /نقد حقيقي/ في  المملكة العربية السعودية",
    'ar-dz': " متاح الآن للربح /نقد حقيقي/ في الجزائر",
    'ar-bh': "متاح الآن للربح /نقد حقيقي/ في  البحرين ",
    'ar-eg': "متاح الآن للربح /نقد حقيقي/ في مصر ",
    'ar-iq': " متاح الآن للربح /نقد حقيقي/ في العراق ",
    'ar-jo': " متاح الآن للربح /نقد حقيقي/ في الأردن ",
    'ar-kw': "متاح الآن للربح /نقد حقيقي/ في الكويت ",
    'ar-lb': "متاح الآن للربح /نقد حقيقي/ في  لبنان ",
    'ar-ly': "متاح الآن للربح /نقد حقيقي/ في  ليبيا",
    'ar-ma': "متاح الآن للربح /نقد حقيقي/ في المغرب",
    'ar-om': " متاح الآن للربح /نقد حقيقي/ في سلطنة عمان",
    'ar-qa': " متاح الآن للربح /نقد حقيقي/ في دولة قطر",
    'ar-sa': " متاح الآن للربح /نقد حقيقي/ في  المملكة العربية السعودية",
    'ar-sy': " متاح الآن للربح /نقد حقيقي/ في سوريا",
    'ar-tn': " متاح الآن للربح /نقد حقيقي/ في تونس ",
    'ar-ae': " متاح الآن للربح /نقد حقيقي/ في الإمارات العربية المتحدة",
    'ar-ye': "  متاح الآن للربح /نقد حقيقي/ في اليمن",
    'ja': "現在可 / 於 / 日本 / 贏取真現鈔！",
    'de': "Jetzt verfügbar, / um Echtgeld in / Deutschland / zu gewinnen!",
    'de-at': "Jetzt verfügbar, / um Echtgeld in / Österreich / zu gewinnen!",
    'de-de': "Jetzt verfügbar, / um Echtgeld in / Deutschland / zu gewinnen!",
    'de-li': "Jetzt verfügbar, / um Echtgeld in / Liechtenstein / zu gewinnen!",
    'de-lu': "Jetzt verfügbar, / um Echtgeld in / Luxemburg / zu gewinnen!",
    'de-ch': "Jetzt verfügbar, / um Echtgeld in / Schweiz / zu gewinnen!",
    'da': "Det er nu muligt / at vinde rigtige penge/ i Danmark!",
    'tr': "Artık Türkiye'de / gerçek para / kazanmak / mümkün!",
    'ru': "Теперь можно / выигрывать настоящие деньги / в / России!",
    'ru-mo': "Теперь можно / выигрывать настоящие деньги / в / Молдове!",
    'uk': "Тепер можна / вигравати справжні гроші / в / Україні!",
    'nl': "Nu beschikbaar om / echt geld te winnen /  in /  Nederland!",
    'nl-be': "Nu beschikbaar om / echt geld te winnen /  in /  België!",
    'fr': "Maintenant disponible pour / gagner de l'argent réel / en / la France!",
    'fr-be': "Maintenant disponible pour / gagner de l'argent réel / en / Belgique!",
    'fr-ca': "Maintenant disponible pour / gagner de l'argent réel / en / Canada!",
    'fr-fr': "Maintenant disponible pour / gagner de l'argent réel / en / la France!",
    'fr-lu': "Maintenant disponible pour / gagner de l'argent réel / en / Luxembourg!",
    'fr-mc': "Maintenant disponible pour / gagner de l'argent réel / en / Monaco!",
    'fr-ch': "Maintenant disponible pour / gagner de l'argent réel / en / Suisse!",
    'ko': "이제 대한민국에서 / 실제 현금을 / 당첨받을 수 / 있습니다!",
    'zh': "现在 / 可以在 / 中国 / 赢取现金了！",
    'zh-sg': "现在 / 新加坡 / 中国 / 赢取现金了！",
    'zh-cn': "现在 / 可以在 / 中国 / 赢取现金了！",
    'zh-hk': "現在可 / 於 / 香港 / 贏取真現鈔！",
    'zh-tw': "現在可以 / 在 台灣 / 贏得真實的 / 現金了！",
    'it': "Ora disponibile / per poter vincere soldi veri / in / Italia!",
    'vi': "Hiện bạn đã có thể / trúng tiền tươi / ở / Việt Nam!",
    'el': "Τώρα διαθέσιμο / για να κερδίσετε χρήματα / στην / Ελλάδα!"
  },
  'Earn your commute!': {
    'en': "Earn your / commute!",
    'es': "¡Gánate el / transporte!",
    'ar': "!اربح / تنقلاتك",
    'ja': "交通費を / 稼ごう！",
    'de': "Verdiene dir / deinen Arbeitsweg!",
    'da': "Tjen dit / køretøj!",
    'tr': "Yol paranı / çıkar!",
    'ru': "Заработай на / транспорт!",
    'uk': "Зароби на / транспорт!",
    'nl': "Verdien je / vervoerskosten!",
    'fr': "Gagnez votre / trajet!",
    'ko': "통근 차량을 / 획득하세요!",
    'zh': "赢得你的 / 通勤费！",
    'zh-hk': "賺取你的 / 通勤費！",
    'it': "Guadagna il tuo / tragitto da pendolare!",
    'vi': "Hãy kiếm / phương tiện đi lại cho bạn!",
    'el': "Κερδίστε τη / μεταφορά σας!"
  },
  'Earn your coffee!': {
    'en': "Earn your / coffee!",
    'es': "¡Gánate el / café!",
    'ar': " !اربح / تنقلاتك",
    'ja': "コーヒー代を / 稼ごう！",
    'de': "Verdiene dir / deinen Kaffee!",
    'da': "Tjen din / kaffe!",
    'tr': "Kahve parası / kazan!",
    'ru': "Заработай на / кофе!",
    'uk': "Зароби на / каву!",
    'nl': "Verdien je / koffie!",
    'fr': "Gagnez votre / café!",
    'ko': "커피를 / 획득하세요!",
    'zh': "赢得你的 / 咖啡钱！",
    'zh-hk': "賺取你的 / 咖啡費用！",
    'it': "Guadagna il tuo / caffè!",
    'vi': "Hãy kiếm / cà phê cho bạn!",
    'el': "Κερδίστε τον / καφέ σας!"
  },
  'Make it rain!': {
    'en': "Make it / rain!",
    'es': "¡Que / llueva!",
    'ar': "فلوس / فلوس",
    'ja': "大金を / ばらまけ！",
    'de': "Lass es / regnen!",
    'da': "Få det til at / regne!",
    'tr': "Para / yağsın!",
    'ru': "Пусть деньги / падают с неба!",
    'uk': "Нехай гроші / падають з неба!",
    'nl': "Laat het / geld regenen!",
    'fr': "Faites-le / pleuvoir!",
    'ko': "돈 벼락을 / 맞으세요!",
    'zh': "让金钱雨 / 下起来！",
    'zh-hk': "讓金錢 / 撒下吧！",
    'it': "Fai / piovere!",
    'vi': "Hãy tạo / mưa!",
    'el': "Βροχή / χρημάτων!"
  },
  'Faster!': {
    'en': "Faster!",
    'es': "¡Más rápido!",
    'ar': "!بسرعة",
    'ja': "もっと速く！",
    'de': "Schneller!",
    'da': "Hurtigere!",
    'tr': "Daha hızlı!",
    'ru': "Быстрее!",
    'nl': "Sneller!",
    'fr': "Plus vite!",
    'ko': "더 빠르게!",
    'zh': "更快一点！",
    'zh-hk': "再快點！",
    'it': "Più veloce!",
    'vi': "Nhanh hơn nữa!",
    'el': "Πιο γρήγορα!"
  },
  "Time's up!": {
    'en': "Time's up!",
    'es': "¡Tiempo!",
    'ar': "!انتهى الوقت",
    'ja': "タイプアップ！",
    'de': "Zeit ist abgelaufen! ",
    'da': "Tiden er gået!",
    'tr': "Süre doldu!",
    'ru': "Время вышло! ",
    'nl': "De tijd is om!",
    'fr': "Le temps est écoulé!",
    'ko': "시간이 다 됐습니다!",
    'zh': "到时间了！",
    'zh-hk': "時間到了！",
    'it': "Tempo scaduto!",
    'vi': "Hết giờ!",
    'el': "Ο χρόνος τελείωσε!"
  },
  'Try it': {
    en: "Try it",
    ja: "「トライ」",
    ko: "플레이해 보세요",
    zh: "试玩",
    de: "Versuch es selbst",
    fr: "Essayez-le",
    it: "Provalo",
    es: "Inténtalo",
    ca: "Intenta-ho",
    ru: "Попробуй",
    uk: "Спробуй",
    el: "Δοκιμάστε το"
  },
  'Next puzzle': {
    en: "Next puzzle",
    ja: "次のパズル",
    ko: "다음 퍼즐",
    zh: "下一个谜题",
    'zh-hk': "下一個謎題",
    de: "Nächstes Rätsel",
    fr: "Puzzle suivant ",
    it: "Prossimo puzzle",
    es: "Siguiente puzzle",
    ca: "Següent trencaclosques",
    pt: "Próximo quebra-cabeças"
  },
  'Upgrade': {
    en: "Upgrade",
    ja: "アップグレード",
    de: "Upgraden",
    fr: "Améliorer",
    it: "Potenzia",
    zh: "升级",
    ko: "업그레이드",
    el: "Αναβάθμιση",
    pt: "Atualizar",
    es: "Mejorar",
    ca: "Millorar"
  },
  'Claim': {
    en: "Claim",
    ja: "獲得",
    de: "Beanspruchen",
    fr: "Obtenir",
    it: "Ottieni",
    zh: "领取",
    ko: "수령",
    el: "Διεκδίκηση",
    pt: "Reclamar",
    es: "Reclamar",
    ca: "Reclamar"
  },
  'Choose': {
    en: "Choose",
    ja: "選択",
    de: "Auswählen",
    fr: "Choisir",
    it: "Scegli",
    zh: "选择",
    ko: "선택",
    el: "Επιλογή",
    pt: "Escolher",
    es: "Escoger",
    ca: "Escollir"
  },
  'Claim now': {
    en: "Claim now",
    ja: "今すぐ獲得",
    de: "Jetzt geltend machen",
    fr: "Se faire payer",
    it: "Richiedi ora",
    zh: "立即领取",
    ko: "지금 받기 요청",
    el: "Διεκδικησε τωρα ",
    es: "Redimir ahora",
    ca: "Reclama ara",
    ru: "Забрать сейчас",
    uk: "Забрати винагороду"
  },
  'Try again': {
    en: "Try again",
    ja: "もう一度試す",
    de: "Erneut versuchen",
    fr: "Réessayer",
    it: "Ritenta",
    zh: "再试一次",
    ko: "다시 시도",
    el: "Δοκιμασε παλι",
    es: "Volver a intentar",
    ca: "Torna a intentar",
    ru: "Попробовать снова",
    uk: "Спробувати ще раз"
  },
  'Stop': {
    en: "Stop",
    ja: "ストップ",
    de: "Stoppen",
    fr: "Arrêter",
    it: "Ferma",
    zh: "停止",
    ko: "중지",
    el: "Σταματησε",
    es: "Stop",
    ca: "Stop",
    ru: "Стоп",
    uk: "Припинити"
  },
  'Loot again': {
    en: "Loot again",
    ja: "もう一度盗む",
    de: "Erneut plündern",
    fr: "Voler à nouveau",
    it: "Ruba ancora",
    zh: "再抢一次",
    ko: "다시 전리품 얻기",
    el: "Κλεψε παλι",
    es: "Aumentar el botín",
    ca: "Saquejar de nou",
    ru: "Украсть снова",
    uk: "Пограбувати ще раз"
  },
  'Jackpot': {
    en: "Jackpot",
    ja: "ジャックポット",
    de: "Jackpot",
    fr: "Jackpot",
    it: "Jackpot",
    zh: "头奖",
    ko: "잭팟",
    el: "Τζακποτ",
    es: "Premio gordo",
    ca: "Jackpot",
    ru: "Джекпот",
    uk: "Джекпот"
  },
  'Retry': {
    en: "Retry",
    ja: "リトライ",
    de: "Versuche es erneut!",
    fr: "Réessayer",
    it: "Riprova",
    zh: "重试",
    ko: "재시도",
    el: "Προσπάθησε ξανά",
    es: "Volver a intentar",
    ca: "Torna a intentar",
    ru: "Повтор",
    uk: "Спробуй знову"
  },
  'Press': {
    en: "Press",
    ja: "押す",
    de: "Drücke!",
    fr: "Appuyer",
    it: "Premi",
    zh: "按",
    ko: "누르기",
    el: "Πάτα",
    es: "Pulsar",
    ca: "Premsa",
    ru: "Нажмите",
    uk: "Натисни "
  },
  'Catch an Egg': {
    en: "Catch an Egg",
    ja: "タマゴをつかむ",
    de: "Fang ein Ei!",
    fr: "Attraper un œuf",
    it: "Prendi un uovo",
    zh: "抓一个鸡蛋",
    ko: "달걀을 잡으세요",
    el: "Πιάσε ένα αβγό",
    es: "Atrapa un huevo",
    ca: "Agafa un ou",
    ru: "Поймай яйцо",
    uk: "Спіймай яйце"
  },
  'Select': {
    en: "Select",
    ja: "選ぶ",
    de: "Auswählen",
    fr: "Sélectionner",
    it: "Seleziona",
    zh: "选择",
    ko: "선택",
    el: "Επιλογή",
    es: "Seleccionar",
    ca: "Seleccioneu",
    ru: "Выбрать",
    uk: "Обрати",
    fi: "Valitse"
  },
  'Tap To Start': {
    en: "Tap To Start",
    ja: "タップして開始する",
    de: "Zum Starten tippen",
    fr: "Appuyez pour commencer",
    it: "Tocca per iniziare",
    zh: "点击以开始",
    ko: "탭해서 시작하기",
    el: "Πάτα Και Ξεκίνα",
    es: "Toca para empezar",
    pt: "Toque para Iniciar",
    ru: "Нажмите, чтобы начать",
    uk: "Торкніться, щоб почати",
    ca: "Toqueu per començar"
  }
};

try {
  if (mraid.getState() === "loading") {
    mraid.addEventListener("ready", mraidReadyHandler);
  } else {
    mraidReadyHandler();
  }
} catch (e) {
  if (e.name === "ReferenceError") {
    // mraid is not defined
    window.addEventListener("load", domReadyHandler);
  }
}