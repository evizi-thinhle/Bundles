"use strict";

var CONFIG = {
  "googlePlayUrl": "",
  "appStoreUrl": "",
  "amazonAppstoreUrl": "",
  "I18": {
    "locale": "en",
    "strings": {
      "Your score: %s": {
        "en": "Your score: %s"
      },
      "Play now": {
        "en": "Play now"
      },
      "Retry": {
        "en": "Retry"
      },
      "goal": {
        "en": "GOAL"
      },
      "pickUp": {
        "en": "PICK UP THREE PASSENGERS"
      },
      "levelC": {
        "en": "LEVEL COMPLETED"
      },
      "levelF": {
        "en": "LEVEL FAILED"
      },
      "newCar": {
        "en": "NEW CAR"
      },
      "cash": {
        "en": "CASH EARNED"
      },
      "topNotch": {
        "en": "Top Notch"
      },
      "getHere": {
        "en": "Get here, pronto!"
      }
    }
  },
  "domBinds": ['tutorial_goal_container', 'tutorial_pointer', 'main_cta_container', 'main_timer_container', 'main_wallet_container', 'main_customers_container', 'final_win_text', 'final_lose_text', 'final_car', 'final_bar_container', 'final_cash_earned_container', 'final_replay_container', 'final_cta_container'],
  "application": {
    "showFPS": false,
    "lightStrength": 0.55,
    // The power of lighting. 
    "timeOnAllWay": 60,
    // Time in a "seconds".
    "playerMaxSpeed": 110,
    // Max velocity 
    "playerAcceleration": 23,
    // Acceleration
    "numOfPassengers": 3,
    // Number of passengers. (1 - 3) 
    "fares": [20, 30, 34],
    // How much passengers pay.
    "endTimer": 8000 // Time to the final screen. If the player does not interact with the game.

  }
};